﻿//------------------------------------------------------------------------------
// <copyright file="KinectSkeletonViewer.xaml.cs" company="Microsoft">
//     Copyright (c) Microsoft Corporation.  All rights reserved.
// </copyright>
//------------------------------------------------------------------------------
using Kinect.Toolbox;
namespace Microsoft.Samples.Kinect.WpfViewers
{
    using System;
    using System.Collections.Generic;
    using System.Windows;
    using System.Windows.Data;
    using Microsoft.Kinect;
    using System.Diagnostics;
    using System.Windows.Media;
    using System.ComponentModel;
    using System.Linq;

    //
    public class MyGrade : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        public string grade = "0";
        public double intgrade = 0;
        public string CyGrade
        {
            get { return grade; }
            set
            {
                grade = value;
                if (PropertyChanged != null)
                {
                    PropertyChanged(this, new PropertyChangedEventArgs("CyGrade"));//对CyGrade进行监听      
                }
            }
        }
        public double IntCyGrade
        {
            get { return intgrade; }
            set
            {
                intgrade = value;
                if (PropertyChanged != null)
                {
                    PropertyChanged(this, new PropertyChangedEventArgs("IntCyGrade"));//对CyGrade进行监听      
                }
            }
        }
    }
    //用于测试
    /*
    public class Student : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private string name;
        public string Name
        {
            get { return name; }
            set
            {
                name = value;
                if (PropertyChanged != null)
                {
                    PropertyChanged.Invoke(this, new PropertyChangedEventArgs("Name"));
                }
            }
        }
    }
    */
    //
    public enum ImageType
    {
        /// <summary>
        /// The Color Image
        /// </summary>
        Color,

        /// <summary>
        /// The Depth Image
        /// </summary>
        Depth,
    }

    /// <summary>
    /// Interaction logic for KinectSkeletonViewer.xaml
    /// </summary>
    public partial class KinectSkeletonViewer : KinectViewer
    {
        public int DetLength = 100;
        private Queue<double> HeadPos = new Queue<double>(100);           //存储任何一个时间段内连续60帧头的高度信息
        private double[] HeadPosArray = new double[100];

        public static readonly DependencyProperty ShowBonesProperty =
            DependencyProperty.Register(
                "ShowBones",
                typeof(bool),
                typeof(KinectSkeletonViewer),
                new PropertyMetadata(true));

        public static readonly DependencyProperty ShowJointsProperty =
            DependencyProperty.Register(
                "ShowJoints",
                typeof(bool),
                typeof(KinectSkeletonViewer),
                new PropertyMetadata(true));

        public static readonly DependencyProperty ShowCenterProperty =
            DependencyProperty.Register(
                "ShowCenter",
                typeof(bool),
                typeof(KinectSkeletonViewer),
                new PropertyMetadata(true));

        public static readonly DependencyProperty ImageTypeProperty =
            DependencyProperty.Register(
                "ImageType",
                typeof(ImageType),
                typeof(KinectSkeletonViewer),
                new PropertyMetadata(ImageType.Color));

        private const int SkeletonCount = 6;
        private readonly List<KinectSkeleton> skeletonCanvases = new List<KinectSkeleton>(SkeletonCount);
        private readonly List<Dictionary<JointType, JointMapping>> jointMappings = new List<Dictionary<JointType, JointMapping>>();
        private Skeleton[] skeletonData;
        Boolean SquatFlag = false;         //判断连续两次的hip knee关节高度变化
        /*
        public static int mygrade;
        public int Grade { get => mygrade; set => mygrade = value; }
        */
        public MyGrade mygrade = new MyGrade();
        public KinectSkeletonViewer()
        {
            InitializeComponent();
            this.ShowJoints = true;
            this.ShowBones = true;
            this.ShowCenter = true;
            mygrade.CyGrade = "0";
        }

        public bool ShowBones
        {
            get { return (bool)GetValue(ShowBonesProperty); }
            set { SetValue(ShowBonesProperty, value); }
        }

        public bool ShowJoints
        {
            get { return (bool)GetValue(ShowJointsProperty); }
            set { SetValue(ShowJointsProperty, value); }
        }

        public bool ShowCenter
        {
            get { return (bool)GetValue(ShowCenterProperty); }
            set { SetValue(ShowCenterProperty, value); }
        }

        public ImageType ImageType
        {
            get { return (ImageType)GetValue(ImageTypeProperty); }
            set { SetValue(ImageTypeProperty, value); }
        }

        protected override void OnKinectSensorChanged(object sender, KinectSensorManagerEventArgs<KinectSensor> args)
        {
            if (null != args.OldValue)
            {
                args.OldValue.AllFramesReady -= this.KinectAllFramesReady;
            }

            if ((null != args.NewValue) && (KinectStatus.Connected == args.NewValue.Status))
            {
                args.NewValue.AllFramesReady += this.KinectAllFramesReady;
            }
        }

        /// <summary>
        /// Returns the 2D position of the provided 3D SkeletonPoint.
        /// The result will be in in either Color coordinate space or Depth coordinate space, depending on 
        /// the current value of this.ImageType.
        /// Only those parameters associated with the current ImageType will be used.
        /// </summary>
        /// <param name="sensor">The KinectSensor for which this mapping is being performed.</param>
        /// <param name="imageType">The target image type</param>
        /// <param name="renderSize">The target dimensions of the visualization</param>
        /// <param name="skeletonPoint">The source point to map</param>
        /// <param name="colorFormat">The format of the target color image, if imageType is Color</param>
        /// <param name="colorWidth">The width of the target color image, if the imageType is Color</param>
        /// <param name="colorHeight">The height of the target color image, if the imageType is Color</param>
        /// <param name="depthFormat">The format of the target depth image, if the imageType is Depth</param>
        /// <param name="depthWidth">The width of the target depth image, if the imageType is Depth</param>
        /// <param name="depthHeight">The height of the target depth image, if the imageType is Depth</param>
        /// <returns>Returns the 2D position of the provided 3D SkeletonPoint.</returns>
        private static Point Get2DPosition(
            KinectSensor sensor,
            ImageType imageType,
            Size renderSize,
            SkeletonPoint skeletonPoint,
            ColorImageFormat colorFormat,
            int colorWidth,
            int colorHeight,
            DepthImageFormat depthFormat,
            int depthWidth,
            int depthHeight)
        {
            try
            {
                switch (imageType)
                {
                    case ImageType.Color:
                        if (ColorImageFormat.Undefined != colorFormat)
                        {
                            var colorPoint = sensor.MapSkeletonPointToColor(skeletonPoint, colorFormat);
                            // map back to skeleton.Width & skeleton.Height

                            return new Point(
                            (int)(renderSize.Width * colorPoint.X / colorWidth),
                            (int)(renderSize.Height * colorPoint.Y / colorHeight));
                        }

                        break;
                    case ImageType.Depth:
                        if (DepthImageFormat.Undefined != depthFormat)
                        {
                            var depthPoint = sensor.MapSkeletonPointToDepth(skeletonPoint, depthFormat);

                            return new Point(
                                (int)(renderSize.Width * depthPoint.X / depthWidth),
                                (int)(renderSize.Height * depthPoint.Y / depthHeight));
                        }

                        break;
                }
            }
            catch (InvalidOperationException)
            {
                // The stream must have stopped abruptly
                // Handle this gracefully
            }

            return new Point();
        }

        private void KinectAllFramesReady(object sender, AllFramesReadyEventArgs e)
        {
            KinectSensor sensor = sender as KinectSensor;

            foreach (var skeletonCanvas in this.skeletonCanvases)
            {
                skeletonCanvas.Skeleton = null;                       //每一副骨架设为空
            }

            // Have we already been "shut down" by the user of this viewer, 
            // or has the SkeletonStream been disabled since this event was posted?
            if ((null == this.KinectSensorManager) || 
                (null == sensor) ||
                (null == sensor.SkeletonStream) ||
                !sensor.SkeletonStream.IsEnabled)
            {
                return;
            }

            bool haveSkeletonData = false;

            using (SkeletonFrame skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame != null)
                {
                    if ((this.skeletonData == null) || (this.skeletonData.Length != skeletonFrame.SkeletonArrayLength))
                    {
                        this.skeletonData = new Skeleton[skeletonFrame.SkeletonArrayLength];
                    }

                    skeletonFrame.CopySkeletonDataTo(this.skeletonData);               //将kinect捕捉到的数据拷贝至骨骼数组

                    haveSkeletonData = true;
                }
            }
            if (haveSkeletonData)
            {
                ColorImageFormat colorFormat = ColorImageFormat.Undefined;
                int colorWidth = 0;
                int colorHeight = 0;

                DepthImageFormat depthFormat = DepthImageFormat.Undefined;
                int depthWidth = 0;
                int depthHeight = 0;

                switch (this.ImageType)
                {
                case ImageType.Color:
                    // Retrieve the current color format, from the frame if present, and from the sensor if not.
                    using (ColorImageFrame colorImageFrame = e.OpenColorImageFrame())
                    {
                        if (null != colorImageFrame)
                        {
                            colorFormat = colorImageFrame.Format;
                            colorWidth = colorImageFrame.Width;
                            colorHeight = colorImageFrame.Height;
                        }
                        else if (null != sensor.ColorStream)
                        {
                            colorFormat = sensor.ColorStream.Format;
                            colorWidth = sensor.ColorStream.FrameWidth;
                            colorHeight = sensor.ColorStream.FrameHeight;
                        }
                    }

                    break;
                case ImageType.Depth:
                    // Retrieve the current depth format, from the frame if present, and from the sensor if not.
                    using (DepthImageFrame depthImageFrame = e.OpenDepthImageFrame())
                    {
                        if (null != depthImageFrame)
                        {
                            depthFormat = depthImageFrame.Format;
                            depthWidth = depthImageFrame.Width;
                            depthHeight = depthImageFrame.Height;
                        }
                        else if (null != sensor.DepthStream)
                        {
                            depthFormat = sensor.DepthStream.Format;
                            depthWidth = sensor.DepthStream.FrameWidth;
                            depthHeight = sensor.DepthStream.FrameHeight;
                        }
                    }

                    break;
                }
                for (int i = 0; i < this.skeletonData.Length && i < this.skeletonCanvases.Count; i++)
                {
                    var skeleton = this.skeletonData[i];
                    var skeletonCanvas = this.skeletonCanvases[i];
                    var jointMapping = this.jointMappings[i];
                    jointMapping.Clear();
                    try
                    {
                        //
                        if (skeleton.TrackingId != 0)
                        {
                            if (IsSquatAction(skeleton) == true)
                            {
                                var IntGrade = int.Parse(mygrade.CyGrade);
                                IntGrade++;
                                mygrade.CyGrade = IntGrade.ToString();
                                mygrade.IntCyGrade += 6 / 5;
                            }
                        }
                        //
                        //
                        /*
                        if (this.HeadPos.Count < DetLength)
                        {
                            if (skeleton.TrackingId != 0)
                            {
                                Joint HeadJoint = new Joint();
                                foreach (Joint joint in skeleton.Joints)
                                {
                                    if (joint.JointType == JointType.Head)
                                        HeadJoint = joint;
                                }
                                this.HeadPos.Enqueue(HeadJoint.Position.Y);                                
                            }
                        }
                        else if (this.HeadPos.Count == DetLength)
                        {
                            if (skeleton.TrackingId != 0)
                            {
                                string str = "";
                                HeadPos.CopyTo(HeadPosArray, 0);
                                foreach (double cur in HeadPosArray)
                                {
                                    str += cur.ToString() + "  ";
                                }
                                Console.WriteLine(str);
                                Console.WriteLine("\n");
                                HeadPos.Dequeue();
                                Joint HeadJoint = new Joint();
                                foreach (Joint joint in skeleton.Joints)
                                {
                                    if (joint.JointType == JointType.Head)
                                        HeadJoint = joint;
                                }
                                this.HeadPos.Enqueue(HeadJoint.Position.Y);
                            }
                        }
                        */
                        //
                        // Transform the data into the correct space
                        // For each joint, we determine the exact X/Y coordinates for the target view
                        foreach (Joint joint in skeleton.Joints)
                        {
                            Point mappedPoint = Get2DPosition(
                                sensor,
                                this.ImageType,
                                this.RenderSize,
                                joint.Position, 
                                colorFormat, 
                                colorWidth, 
                                colorHeight, 
                                depthFormat, 
                                depthWidth, 
                                depthHeight);

                            jointMapping[joint.JointType] = new JointMapping
                            {
                                Joint = joint,
                                MappedPoint = mappedPoint
                            };
                        }
                    }
                    catch (UnauthorizedAccessException)
                    {
                        // Kinect is no longer available.
                        return;
                    }

                    // Look up the center point
                    Point centerPoint = Get2DPosition(
                        sensor,
                        this.ImageType,
                        this.RenderSize,
                        skeleton.Position, 
                        colorFormat, 
                        colorWidth, 
                        colorHeight, 
                        depthFormat, 
                        depthWidth, 
                        depthHeight);

                    // Scale the skeleton thickness
                    // 1.0 is the desired size at 640 width
                    double scale = this.RenderSize.Width / 640;

                    skeletonCanvas.Skeleton = skeleton;
                    skeletonCanvas.JointMappings = jointMapping;
                    skeletonCanvas.Center = centerPoint;
                    skeletonCanvas.ScaleFactor = scale;
                }
            }
        }

        private void KinectSkeletonViewer_OnLoaded(object sender, RoutedEventArgs e)
        {
            // Build a set of Skeletons, and bind each of their control properties to those
            // exposed on this class so that changes are propagated.
            for (int i = 0; i < SkeletonCount; i++)
            {
                var skeletonCanvas = new KinectSkeleton();
                skeletonCanvas.ClipToBounds = true;

                var showBonesBinding = new Binding("ShowBones");
                showBonesBinding.Source = this;
                skeletonCanvas.SetBinding(KinectSkeleton.ShowBonesProperty, showBonesBinding);

                var showJointsBinding = new Binding("ShowJoints");
                showJointsBinding.Source = this;
                skeletonCanvas.SetBinding(KinectSkeleton.ShowJointsProperty, showJointsBinding);

                var showCenterBinding = new Binding("ShowCenter");
                showCenterBinding.Source = this;
                skeletonCanvas.SetBinding(KinectSkeleton.ShowCenterProperty, showCenterBinding);

                this.skeletonCanvases.Add(skeletonCanvas);
                this.jointMappings.Add(new Dictionary<JointType, JointMapping>());
                this.SkeletonCanvasPanel.Children.Add(skeletonCanvas);

                //

            }
        }

        private bool IsSquatAction(Skeleton skeleton)
        {
            Joint righthip = (from j in skeleton.Joints
                              where j.JointType == JointType.HipRight
                              select j).FirstOrDefault();
            Joint rightknee = (from j in skeleton.Joints
                               where j.JointType == JointType.KneeRight
                               select j).FirstOrDefault();
            if (!(righthip.TrackingState == JointTrackingState.Tracked && rightknee.TrackingState == JointTrackingState.Tracked))
                return false;

            if (righthip.Position.Y < rightknee.Position.Y + 0.2)
                SquatFlag = true;
            if ((righthip.Position.Y> rightknee.Position.Y + 0.2)&&SquatFlag)
            {
                SquatFlag = false;
                return true;
            }
            return false;
        }

        private double GetAngle(Joint joint1, Joint joint2, Joint joint3)
        {
            Vector4 Body_vec1 = new Vector4();
            Vector4 Body_vec2 = new Vector4();
            Body_vec1.Z = 0;
            Body_vec2.Z = 0;
            Body_vec1.X = joint1.Position.X - joint2.Position.X;
            Body_vec1.Y = joint1.Position.Y - joint2.Position.Y;
            Body_vec1.Z = joint1.Position.Z - joint2.Position.Z;
            Body_vec2.X = joint3.Position.X - joint2.Position.X;
            Body_vec2.Y = joint3.Position.Y - joint2.Position.Y;
            Body_vec2.Z = joint3.Position.Z - joint2.Position.Z;

            double length1 = Math.Sqrt(Body_vec1.X * Body_vec1.X + Body_vec1.Y * Body_vec1.Y + Body_vec1.Z * Body_vec1.Z);
            double length2 = Math.Sqrt(Body_vec2.X * Body_vec2.X + Body_vec2.Y * Body_vec2.Y + Body_vec2.Z * Body_vec2.Z);
            double Dotproduct = Body_vec1.X * Body_vec2.X + Body_vec1.Y * Body_vec2.Y + Body_vec1.Z * Body_vec2.Z;
            double Angle = Math.Acos(Dotproduct / length1 / length2) / Math.PI * 180;
            return Angle;
        }
        //
    }
}
