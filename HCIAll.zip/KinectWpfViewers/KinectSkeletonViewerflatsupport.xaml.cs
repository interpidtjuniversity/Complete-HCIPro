﻿using Kinect.Toolbox;
namespace Microsoft.Samples.Kinect.WpfViewers
{
    using System;
    using System.Collections.Generic;
    using System.Windows;
    using System.Windows.Data;
    using Microsoft.Kinect;
    using System.Diagnostics;
    using System.Windows.Media;
    using System.ComponentModel;
    using System.Linq;
    using System.Windows.Threading;

    //
    public enum ImageTypeflatsupport
    {
        /// <summary>
        /// The Color Image
        /// </summary>
        Color,

        /// <summary>
        /// The Depth Image
        /// </summary>
        Depth,
    }

    /// <summary>
    /// Interaction logic for KinectSkeletonViewer.xaml
    /// </summary>
    public partial class KinectSkeletonViewerflatsupport : KinectViewer
    {
        public int DetLengthflatsupport = 100;
        private Queue<double> HeadPosflatsupport = new Queue<double>(100);           //存储任何一个时间段内连续60帧头的高度信息
        private double[] HeadPosArrayflatsupport = new double[100];

        public static readonly DependencyProperty ShowBonesPropertyflatsupport =
            DependencyProperty.Register(
                "ShowBonesflatsupport",
                typeof(bool),
                typeof(KinectSkeletonViewerflatsupport),
                new PropertyMetadata(true));

        public static readonly DependencyProperty ShowJointsPropertyflatsupport =
            DependencyProperty.Register(
                "ShowJointsflatsupport",
                typeof(bool),
                typeof(KinectSkeletonViewerflatsupport),
                new PropertyMetadata(true));

        public static readonly DependencyProperty ShowCenterPropertyflatsupport =
            DependencyProperty.Register(
                "ShowCenterflatsupport",
                typeof(bool),
                typeof(KinectSkeletonViewerflatsupport),
                new PropertyMetadata(true));

        public static readonly DependencyProperty ImageTypePropertyflatsupport =
            DependencyProperty.Register(
                "ImageTypeflatsupport",
                typeof(ImageType),
                typeof(KinectSkeletonViewerflatsupport),
                new PropertyMetadata(ImageType.Color));
        private const int SkeletonCountflatsupport = 6;
        private readonly List<KinectSkeletonflatsupport> skeletonCanvasesflatsupport = new List<KinectSkeletonflatsupport>(SkeletonCountflatsupport);
        private readonly List<Dictionary<JointType, JointMapping>> jointMappingsflatsupport = new List<Dictionary<JointType, JointMapping>>();
        private Skeleton[] skeletonDataflatsupport;
        DispatcherTimer clc = new DispatcherTimer();           //定时器
        /*
        public static int mygrade;
        public int Grade { get => mygrade; set => mygrade = value; }
        */
        public MyGrade mygradeflatsupport = new MyGrade();
        public KinectSkeletonViewerflatsupport()
        {
            InitializeComponent();
            this.ShowJointflatsupport = true;
            this.ShowBonesflatsupport = true;
            this.ShowCenterflatsupport = true;
            mygradeflatsupport.CyGrade = "0";
            clc.Interval = new TimeSpan(0, 0, 1);
            clc.Tick += new EventHandler(clc_change);
        }

        public bool ShowBonesflatsupport
        {
            get { return (bool)GetValue(ShowBonesPropertyflatsupport); }
            set { SetValue(ShowBonesPropertyflatsupport, value); }
        }

        public bool ShowJointflatsupport
        {
            get { return (bool)GetValue(ShowJointsPropertyflatsupport); }
            set { SetValue(ShowJointsPropertyflatsupport, value); }
        }

        public bool ShowCenterflatsupport
        {
            get { return (bool)GetValue(ShowCenterPropertyflatsupport); }
            set { SetValue(ShowCenterPropertyflatsupport, value); }
        }

        public ImageType ImageTypeflatsupport
        {
            get { return (ImageType)GetValue(ImageTypePropertyflatsupport); }
            set { SetValue(ImageTypePropertyflatsupport, value); }
        }

        protected override void OnKinectSensorChanged(object sender, KinectSensorManagerEventArgs<KinectSensor> args)
        {
            if (null != args.OldValue)
            {
                args.OldValue.AllFramesReady -= this.KinectAllFramesReady;
            }

            if ((null != args.NewValue) && (KinectStatus.Connected == args.NewValue.Status))
            {
                args.NewValue.AllFramesReady += this.KinectAllFramesReady;
            }
        }

        /// <summary>
        /// Returns the 2D position of the provided 3D SkeletonPoint.
        /// The result will be in in either Color coordinate space or Depth coordinate space, depending on 
        /// the current value of this.ImageType.
        /// Only those parameters associated with the current ImageType will be used.
        /// </summary>
        /// <param name="sensor">The KinectSensor for which this mapping is being performed.</param>
        /// <param name="imageType">The target image type</param>
        /// <param name="renderSize">The target dimensions of the visualization</param>
        /// <param name="skeletonPoint">The source point to map</param>
        /// <param name="colorFormat">The format of the target color image, if imageType is Color</param>
        /// <param name="colorWidth">The width of the target color image, if the imageType is Color</param>
        /// <param name="colorHeight">The height of the target color image, if the imageType is Color</param>
        /// <param name="depthFormat">The format of the target depth image, if the imageType is Depth</param>
        /// <param name="depthWidth">The width of the target depth image, if the imageType is Depth</param>
        /// <param name="depthHeight">The height of the target depth image, if the imageType is Depth</param>
        /// <returns>Returns the 2D position of the provided 3D SkeletonPoint.</returns>
        private static Point Get2DPosition(
            KinectSensor sensor,
            ImageType imageType,
            Size renderSize,
            SkeletonPoint skeletonPoint,
            ColorImageFormat colorFormat,
            int colorWidth,
            int colorHeight,
            DepthImageFormat depthFormat,
            int depthWidth,
            int depthHeight)
        {
            try
            {
                switch (imageType)
                {
                    case ImageType.Color:
                        if (ColorImageFormat.Undefined != colorFormat)
                        {
                            var colorPoint = sensor.MapSkeletonPointToColor(skeletonPoint, colorFormat);
                            // map back to skeleton.Width & skeleton.Height

                            return new Point(
                            (int)(renderSize.Width * colorPoint.X / colorWidth),
                            (int)(renderSize.Height * colorPoint.Y / colorHeight));
                        }

                        break;
                    case ImageType.Depth:
                        if (DepthImageFormat.Undefined != depthFormat)
                        {
                            var depthPoint = sensor.MapSkeletonPointToDepth(skeletonPoint, depthFormat);

                            return new Point(
                                (int)(renderSize.Width * depthPoint.X / depthWidth),
                                (int)(renderSize.Height * depthPoint.Y / depthHeight));
                        }

                        break;
                }
            }
            catch (InvalidOperationException)
            {
                // The stream must have stopped abruptly
                // Handle this gracefully
            }

            return new Point();
        }

        private void KinectAllFramesReady(object sender, AllFramesReadyEventArgs e)
        {
            KinectSensor sensor = sender as KinectSensor;

            foreach (var skeletonCanvas in this.skeletonCanvasesflatsupport)
            {
                skeletonCanvas.Skeleton = null;                       //每一副骨架设为空
            }

            // Have we already been "shut down" by the user of this viewer, 
            // or has the SkeletonStream been disabled since this event was posted?
            if ((null == this.KinectSensorManager) ||
                (null == sensor) ||
                (null == sensor.SkeletonStream) ||
                !sensor.SkeletonStream.IsEnabled)
            {
                return;
            }

            bool haveSkeletonData = false;

            using (SkeletonFrame skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame != null)
                {
                    if ((this.skeletonDataflatsupport == null) || (this.skeletonDataflatsupport.Length != skeletonFrame.SkeletonArrayLength))
                    {
                        this.skeletonDataflatsupport = new Skeleton[skeletonFrame.SkeletonArrayLength];
                    }

                    skeletonFrame.CopySkeletonDataTo(this.skeletonDataflatsupport);               //将kinect捕捉到的数据拷贝至骨骼数组

                    haveSkeletonData = true;
                }
            }
            if (haveSkeletonData)
            {
                ColorImageFormat colorFormat = ColorImageFormat.Undefined;
                int colorWidth = 0;
                int colorHeight = 0;

                DepthImageFormat depthFormat = DepthImageFormat.Undefined;
                int depthWidth = 0;
                int depthHeight = 0;

                switch (this.ImageTypeflatsupport)
                {
                    case ImageType.Color:
                        // Retrieve the current color format, from the frame if present, and from the sensor if not.
                        using (ColorImageFrame colorImageFrame = e.OpenColorImageFrame())
                        {
                            if (null != colorImageFrame)
                            {
                                colorFormat = colorImageFrame.Format;
                                colorWidth = colorImageFrame.Width;
                                colorHeight = colorImageFrame.Height;
                            }
                            else if (null != sensor.ColorStream)
                            {
                                colorFormat = sensor.ColorStream.Format;
                                colorWidth = sensor.ColorStream.FrameWidth;
                                colorHeight = sensor.ColorStream.FrameHeight;
                            }
                        }

                        break;
                    case ImageType.Depth:
                        // Retrieve the current depth format, from the frame if present, and from the sensor if not.
                        using (DepthImageFrame depthImageFrame = e.OpenDepthImageFrame())
                        {
                            if (null != depthImageFrame)
                            {
                                depthFormat = depthImageFrame.Format;
                                depthWidth = depthImageFrame.Width;
                                depthHeight = depthImageFrame.Height;
                            }
                            else if (null != sensor.DepthStream)
                            {
                                depthFormat = sensor.DepthStream.Format;
                                depthWidth = sensor.DepthStream.FrameWidth;
                                depthHeight = sensor.DepthStream.FrameHeight;
                            }
                        }

                        break;
                }
                for (int i = 0; i < this.skeletonDataflatsupport.Length && i < this.skeletonCanvasesflatsupport.Count; i++)
                {
                    if (skeletonDataflatsupport[i] == null)
                        clc.Stop();

                    var skeleton = this.skeletonDataflatsupport[i];
                    var skeletonCanvas = this.skeletonCanvasesflatsupport[i];
                    var jointMapping = this.jointMappingsflatsupport[i];
                    jointMapping.Clear();
                    try
                    {
                        if (skeleton.TrackingId != 0)
                        {
                            if (IsFlatSupportAction(skeleton) == true)
                            {
                                clc.Start();
                            }
                            else
                            {
                                clc.Stop();
                            }
                        }
                        //
                        //
                        /*
                        if (this.HeadPos.Count < DetLength)
                        {
                            if (skeleton.TrackingId != 0)
                            {
                                Joint HeadJoint = new Joint();
                                foreach (Joint joint in skeleton.Joints)
                                {
                                    if (joint.JointType == JointType.Head)
                                        HeadJoint = joint;
                                }
                                this.HeadPos.Enqueue(HeadJoint.Position.Y);                                
                            }
                        }
                        else if (this.HeadPos.Count == DetLength)
                        {
                            if (skeleton.TrackingId != 0)
                            {
                                string str = "";
                                HeadPos.CopyTo(HeadPosArray, 0);
                                foreach (double cur in HeadPosArray)
                                {
                                    str += cur.ToString() + "  ";
                                }
                                Console.WriteLine(str);
                                Console.WriteLine("\n");
                                HeadPos.Dequeue();
                                Joint HeadJoint = new Joint();
                                foreach (Joint joint in skeleton.Joints)
                                {
                                    if (joint.JointType == JointType.Head)
                                        HeadJoint = joint;
                                }
                                this.HeadPos.Enqueue(HeadJoint.Position.Y);
                            }
                        }
                        */
                        //
                        // Transform the data into the correct space
                        // For each joint, we determine the exact X/Y coordinates for the target view
                        foreach (Joint joint in skeleton.Joints)
                        {
                            Point mappedPoint = Get2DPosition(
                                sensor,
                                this.ImageTypeflatsupport,
                                this.RenderSize,
                                joint.Position,
                                colorFormat,
                                colorWidth,
                                colorHeight,
                                depthFormat,
                                depthWidth,
                                depthHeight);

                            jointMapping[joint.JointType] = new JointMapping
                            {
                                Joint = joint,
                                MappedPoint = mappedPoint
                            };
                        }
                    }
                    catch (UnauthorizedAccessException)
                    {
                        // Kinect is no longer available.
                        return;
                    }

                    // Look up the center point
                    Point centerPoint = Get2DPosition(
                        sensor,
                        this.ImageTypeflatsupport,
                        this.RenderSize,
                        skeleton.Position,
                        colorFormat,
                        colorWidth,
                        colorHeight,
                        depthFormat,
                        depthWidth,
                        depthHeight);

                    // Scale the skeleton thickness
                    // 1.0 is the desired size at 640 width
                    double scale = this.RenderSize.Width / 640;

                    skeletonCanvas.Skeleton = skeleton;
                    skeletonCanvas.JointMappings = jointMapping;
                    skeletonCanvas.Center = centerPoint;
                    skeletonCanvas.ScaleFactor = scale;
                }
            }
        }

        private void KinectSkeletonViewer_OnLoadedflatsupport(object sender, RoutedEventArgs e)
        {
            // Build a set of Skeletons, and bind each of their control properties to those
            // exposed on this class so that changes are propagated.
            for (int i = 0; i < SkeletonCountflatsupport; i++)
            {
                var skeletonCanvas = new KinectSkeletonflatsupport();
                skeletonCanvas.ClipToBounds = true;

                var showBonesBinding = new Binding("ShowBonesflatsupport");
                showBonesBinding.Source = this;
                skeletonCanvas.SetBinding(KinectSkeletonflatsupport.ShowBonesPropertyflatsupport, showBonesBinding);

                var showJointsBinding = new Binding("ShowJointsflatsupport");
                showJointsBinding.Source = this;
                skeletonCanvas.SetBinding(KinectSkeletonflatsupport.ShowJointsPropertyflatsupport, showJointsBinding);

                var showCenterBinding = new Binding("ShowCenterflatsupport");
                showCenterBinding.Source = this;
                skeletonCanvas.SetBinding(KinectSkeletonflatsupport.ShowCenterProperty, showCenterBinding);

                this.skeletonCanvasesflatsupport.Add(skeletonCanvas);
                this.jointMappingsflatsupport.Add(new Dictionary<JointType, JointMapping>());
                this.SkeletonCanvasPanelflatsupport.Children.Add(skeletonCanvas);
                //

            }
        }
        private double GetAngle(Joint joint1, Joint joint2, Joint joint3)
        {
            Vector4 Body_vec1 = new Vector4();
            Vector4 Body_vec2 = new Vector4();
            Body_vec1.Z = 0;
            Body_vec2.Z = 0;
            Body_vec1.X = joint1.Position.X - joint2.Position.X;
            Body_vec1.Y = joint1.Position.Y - joint2.Position.Y;
            Body_vec1.Z = joint1.Position.Z - joint2.Position.Z;
            Body_vec2.X = joint3.Position.X - joint2.Position.X;
            Body_vec2.Y = joint3.Position.Y - joint2.Position.Y;
            Body_vec2.Z = joint3.Position.Z - joint2.Position.Z;

            double length1 = Math.Sqrt(Body_vec1.X * Body_vec1.X + Body_vec1.Y * Body_vec1.Y + Body_vec1.Z * Body_vec1.Z);
            double length2 = Math.Sqrt(Body_vec2.X * Body_vec2.X + Body_vec2.Y * Body_vec2.Y + Body_vec2.Z * Body_vec2.Z);
            double Dotproduct = Body_vec1.X * Body_vec2.X + Body_vec1.Y * Body_vec2.Y + Body_vec1.Z * Body_vec2.Z;
            double Angle = Math.Acos(Dotproduct / length1 / length2) / Math.PI * 180;
            return Angle;
        }
        //
        private bool IsFlatSupportAction(Skeleton skeleton)
        {
            Joint head = (from j in skeleton.Joints
                              where j.JointType == JointType.Head
                              select j).FirstOrDefault();
            Joint hipcenter = (from j in skeleton.Joints
                               where j.JointType == JointType.HipCenter
                               select j).FirstOrDefault();
            if (head.Position.Y <= hipcenter.Position.Y + 0.4)
                return true;
            else
                return false;
        }

        private void clc_change(object sender,EventArgs e)
        {
            var IntGrade = int.Parse(mygradeflatsupport.CyGrade);
            IntGrade++;
            mygradeflatsupport.CyGrade = IntGrade.ToString();
            mygradeflatsupport.IntCyGrade += 6 / 5;
        }
    }
}

