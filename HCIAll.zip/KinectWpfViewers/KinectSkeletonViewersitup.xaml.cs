﻿using Kinect.Toolbox;
namespace Microsoft.Samples.Kinect.WpfViewers
{
    using System;
    using System.Collections.Generic;
    using System.Windows;
    using System.Windows.Data;
    using Microsoft.Kinect;
    using System.Diagnostics;
    using System.Windows.Media;
    using System.ComponentModel;
    using System.Linq;

    //
    public enum ImageTypesitup
    {
        /// <summary>
        /// The Color Image
        /// </summary>
        Color,

        /// <summary>
        /// The Depth Image
        /// </summary>
        Depth,
    }

    /// <summary>
    /// Interaction logic for KinectSkeletonViewer.xaml
    /// </summary>
    public partial class KinectSkeletonViewersitup : KinectViewer
    {
        public int DetLengthsitup = 100;
        private Queue<double> HeadPossitup = new Queue<double>(100);           //存储任何一个时间段内连续60帧头的高度信息
        private double[] HeadPosArraysitup = new double[100];

        public static readonly DependencyProperty ShowBonesPropertysitup =
            DependencyProperty.Register(
                "ShowBonessitup",
                typeof(bool),
                typeof(KinectSkeletonViewersitup),
                new PropertyMetadata(true));

        public static readonly DependencyProperty ShowJointsPropertysitup =
            DependencyProperty.Register(
                "ShowJointssitup",
                typeof(bool),
                typeof(KinectSkeletonViewersitup),
                new PropertyMetadata(true));

        public static readonly DependencyProperty ShowCenterPropertysitup =
            DependencyProperty.Register(
                "ShowCentersitup",
                typeof(bool),
                typeof(KinectSkeletonViewersitup),
                new PropertyMetadata(true));

        public static readonly DependencyProperty ImageTypePropertysitup =
            DependencyProperty.Register(
                "ImageTypesitup",
                typeof(ImageType),
                typeof(KinectSkeletonViewersitup),
                new PropertyMetadata(ImageType.Color));
        private const int SkeletonCountsitup = 6;
        private readonly List<KinectSkeletonsitup> skeletonCanvasessitup = new List<KinectSkeletonsitup>(SkeletonCountsitup);
        private readonly List<Dictionary<JointType, JointMapping>> jointMappingssitup = new List<Dictionary<JointType, JointMapping>>();
        private Skeleton[] skeletonDatasitup;
        Boolean SitUpFlag = false;         //判断连续两次的腹部夹角
        /*
        public static int mygrade;
        public int Grade { get => mygrade; set => mygrade = value; }
        */
        public MyGrade mygradesitup = new MyGrade();
        public KinectSkeletonViewersitup()
        {
            InitializeComponent();
            this.ShowJointsitup = true;
            this.ShowBonessitup = true;
            this.ShowCentersitup = true;
            mygradesitup.CyGrade = "0";
        }
        
        public bool ShowBonessitup
        {
            get { return (bool)GetValue(ShowBonesPropertysitup); }
            set { SetValue(ShowBonesPropertysitup, value); }
        }

        public bool ShowJointsitup
        {
            get { return (bool)GetValue(ShowJointsPropertysitup); }
            set { SetValue(ShowJointsPropertysitup, value); }
        }

        public bool ShowCentersitup
        {
            get { return (bool)GetValue(ShowCenterPropertysitup); }
            set { SetValue(ShowCenterPropertysitup, value); }
        }

        public ImageType ImageTypesitup
        {
            get { return (ImageType)GetValue(ImageTypePropertysitup); }
            set { SetValue(ImageTypePropertysitup, value); }
        }

        protected override void OnKinectSensorChanged(object sender, KinectSensorManagerEventArgs<KinectSensor> args)
        {
            if (null != args.OldValue)
            {
                args.OldValue.AllFramesReady -= this.KinectAllFramesReady;
            }

            if ((null != args.NewValue) && (KinectStatus.Connected == args.NewValue.Status))
            {
                args.NewValue.AllFramesReady += this.KinectAllFramesReady;
            }
        }

        /// <summary>
        /// Returns the 2D position of the provided 3D SkeletonPoint.
        /// The result will be in in either Color coordinate space or Depth coordinate space, depending on 
        /// the current value of this.ImageType.
        /// Only those parameters associated with the current ImageType will be used.
        /// </summary>
        /// <param name="sensor">The KinectSensor for which this mapping is being performed.</param>
        /// <param name="imageType">The target image type</param>
        /// <param name="renderSize">The target dimensions of the visualization</param>
        /// <param name="skeletonPoint">The source point to map</param>
        /// <param name="colorFormat">The format of the target color image, if imageType is Color</param>
        /// <param name="colorWidth">The width of the target color image, if the imageType is Color</param>
        /// <param name="colorHeight">The height of the target color image, if the imageType is Color</param>
        /// <param name="depthFormat">The format of the target depth image, if the imageType is Depth</param>
        /// <param name="depthWidth">The width of the target depth image, if the imageType is Depth</param>
        /// <param name="depthHeight">The height of the target depth image, if the imageType is Depth</param>
        /// <returns>Returns the 2D position of the provided 3D SkeletonPoint.</returns>
        private static Point Get2DPosition(
            KinectSensor sensor,
            ImageType imageType,
            Size renderSize,
            SkeletonPoint skeletonPoint,
            ColorImageFormat colorFormat,
            int colorWidth,
            int colorHeight,
            DepthImageFormat depthFormat,
            int depthWidth,
            int depthHeight)
        {
            try
            {
                switch (imageType)
                {
                    case ImageType.Color:
                        if (ColorImageFormat.Undefined != colorFormat)
                        {
                            var colorPoint = sensor.MapSkeletonPointToColor(skeletonPoint, colorFormat);
                            // map back to skeleton.Width & skeleton.Height

                            return new Point(
                            (int)(renderSize.Width * colorPoint.X / colorWidth),
                            (int)(renderSize.Height * colorPoint.Y / colorHeight));
                        }

                        break;
                    case ImageType.Depth:
                        if (DepthImageFormat.Undefined != depthFormat)
                        {
                            var depthPoint = sensor.MapSkeletonPointToDepth(skeletonPoint, depthFormat);

                            return new Point(
                                (int)(renderSize.Width * depthPoint.X / depthWidth),
                                (int)(renderSize.Height * depthPoint.Y / depthHeight));
                        }

                        break;
                }
            }
            catch (InvalidOperationException)
            {
                // The stream must have stopped abruptly
                // Handle this gracefully
            }

            return new Point();
        }

        private void KinectAllFramesReady(object sender, AllFramesReadyEventArgs e)
        {
            KinectSensor sensor = sender as KinectSensor;

            foreach (var skeletonCanvas in this.skeletonCanvasessitup)
            {
                skeletonCanvas.Skeleton = null;                       //每一副骨架设为空
            }

            // Have we already been "shut down" by the user of this viewer, 
            // or has the SkeletonStream been disabled since this event was posted?
            if ((null == this.KinectSensorManager) ||
                (null == sensor) ||
                (null == sensor.SkeletonStream) ||
                !sensor.SkeletonStream.IsEnabled)
            {
                return;
            }

            bool haveSkeletonData = false;

            using (SkeletonFrame skeletonFrame = e.OpenSkeletonFrame())
            {
                if (skeletonFrame != null)
                {
                    if ((this.skeletonDatasitup == null) || (this.skeletonDatasitup.Length != skeletonFrame.SkeletonArrayLength))
                    {
                        this.skeletonDatasitup = new Skeleton[skeletonFrame.SkeletonArrayLength];
                    }

                    skeletonFrame.CopySkeletonDataTo(this.skeletonDatasitup);               //将kinect捕捉到的数据拷贝至骨骼数组

                    haveSkeletonData = true;
                }
            }
            if (haveSkeletonData)
            {
                ColorImageFormat colorFormat = ColorImageFormat.Undefined;
                int colorWidth = 0;
                int colorHeight = 0;

                DepthImageFormat depthFormat = DepthImageFormat.Undefined;
                int depthWidth = 0;
                int depthHeight = 0;

                switch (this.ImageTypesitup)
                {
                    case ImageType.Color:
                        // Retrieve the current color format, from the frame if present, and from the sensor if not.
                        using (ColorImageFrame colorImageFrame = e.OpenColorImageFrame())
                        {
                            if (null != colorImageFrame)
                            {
                                colorFormat = colorImageFrame.Format;
                                colorWidth = colorImageFrame.Width;
                                colorHeight = colorImageFrame.Height;
                            }
                            else if (null != sensor.ColorStream)
                            {
                                colorFormat = sensor.ColorStream.Format;
                                colorWidth = sensor.ColorStream.FrameWidth;
                                colorHeight = sensor.ColorStream.FrameHeight;
                            }
                        }

                        break;
                    case ImageType.Depth:
                        // Retrieve the current depth format, from the frame if present, and from the sensor if not.
                        using (DepthImageFrame depthImageFrame = e.OpenDepthImageFrame())
                        {
                            if (null != depthImageFrame)
                            {
                                depthFormat = depthImageFrame.Format;
                                depthWidth = depthImageFrame.Width;
                                depthHeight = depthImageFrame.Height;
                            }
                            else if (null != sensor.DepthStream)
                            {
                                depthFormat = sensor.DepthStream.Format;
                                depthWidth = sensor.DepthStream.FrameWidth;
                                depthHeight = sensor.DepthStream.FrameHeight;
                            }
                        }

                        break;
                }
                for (int i = 0; i < this.skeletonDatasitup.Length && i < this.skeletonCanvasessitup.Count; i++)
                {
                    var skeleton = this.skeletonDatasitup[i];
                    var skeletonCanvas = this.skeletonCanvasessitup[i];
                    var jointMapping = this.jointMappingssitup[i];
                    jointMapping.Clear();
                    try
                    {
                        //
                        if (skeleton.TrackingId != 0)
                        {
                            if (IsSitUpAction(skeleton) == true)
                            {
                                var IntGrade = int.Parse(mygradesitup.CyGrade);
                                IntGrade++;
                                mygradesitup.CyGrade = IntGrade.ToString();
                                mygradesitup.IntCyGrade += 6 / 5;
                            }
                        }
                        //
                        //
                        /*
                        if (this.HeadPos.Count < DetLength)
                        {
                            if (skeleton.TrackingId != 0)
                            {
                                Joint HeadJoint = new Joint();
                                foreach (Joint joint in skeleton.Joints)
                                {
                                    if (joint.JointType == JointType.Head)
                                        HeadJoint = joint;
                                }
                                this.HeadPos.Enqueue(HeadJoint.Position.Y);                                
                            }
                        }
                        else if (this.HeadPos.Count == DetLength)
                        {
                            if (skeleton.TrackingId != 0)
                            {
                                string str = "";
                                HeadPos.CopyTo(HeadPosArray, 0);
                                foreach (double cur in HeadPosArray)
                                {
                                    str += cur.ToString() + "  ";
                                }
                                Console.WriteLine(str);
                                Console.WriteLine("\n");
                                HeadPos.Dequeue();
                                Joint HeadJoint = new Joint();
                                foreach (Joint joint in skeleton.Joints)
                                {
                                    if (joint.JointType == JointType.Head)
                                        HeadJoint = joint;
                                }
                                this.HeadPos.Enqueue(HeadJoint.Position.Y);
                            }
                        }
                        */
                        //
                        // Transform the data into the correct space
                        // For each joint, we determine the exact X/Y coordinates for the target view
                        foreach (Joint joint in skeleton.Joints)
                        {
                            Point mappedPoint = Get2DPosition(
                                sensor,
                                this.ImageTypesitup,
                                this.RenderSize,
                                joint.Position,
                                colorFormat,
                                colorWidth,
                                colorHeight,
                                depthFormat,
                                depthWidth,
                                depthHeight);

                            jointMapping[joint.JointType] = new JointMapping
                            {
                                Joint = joint,
                                MappedPoint = mappedPoint
                            };
                        }
                    }
                    catch (UnauthorizedAccessException)
                    {
                        // Kinect is no longer available.
                        return;
                    }

                    // Look up the center point
                    Point centerPoint = Get2DPosition(
                        sensor,
                        this.ImageTypesitup,
                        this.RenderSize,
                        skeleton.Position,
                        colorFormat,
                        colorWidth,
                        colorHeight,
                        depthFormat,
                        depthWidth,
                        depthHeight);

                    // Scale the skeleton thickness
                    // 1.0 is the desired size at 640 width
                    double scale = this.RenderSize.Width / 640;

                    skeletonCanvas.Skeleton = skeleton;
                    skeletonCanvas.JointMappings = jointMapping;
                    skeletonCanvas.Center = centerPoint;
                    skeletonCanvas.ScaleFactor = scale;
                }
            }
        }

        private void KinectSkeletonViewer_OnLoadedsitup(object sender, RoutedEventArgs e)
        {
            // Build a set of Skeletons, and bind each of their control properties to those
            // exposed on this class so that changes are propagated.
            for (int i = 0; i < SkeletonCountsitup; i++)
            {
                var skeletonCanvas = new KinectSkeletonsitup();
                skeletonCanvas.ClipToBounds = true;

                var showBonesBinding = new Binding("ShowBonessitup");
                showBonesBinding.Source = this;
                skeletonCanvas.SetBinding(KinectSkeletonsitup.ShowBonesPropertysitup, showBonesBinding);

                var showJointsBinding = new Binding("ShowJointssitup");
                showJointsBinding.Source = this;
                skeletonCanvas.SetBinding(KinectSkeletonsitup.ShowJointsPropertysitup, showJointsBinding);

                var showCenterBinding = new Binding("ShowCentersitup");
                showCenterBinding.Source = this;
                skeletonCanvas.SetBinding(KinectSkeletonsitup.ShowCenterProperty, showCenterBinding);

                this.skeletonCanvasessitup.Add(skeletonCanvas);
                this.jointMappingssitup.Add(new Dictionary<JointType, JointMapping>());
                this.SkeletonCanvasPanelsitup.Children.Add(skeletonCanvas);

                //

            }
        }

        private bool IsSitUpAction(Skeleton skeleton)
        {
            Joint Headjoint = (from j in skeleton.Joints
                              where j.JointType == JointType.Head
                              select j).FirstOrDefault();
            Joint HipCenterjoint = (from j in skeleton.Joints
                               where j.JointType == JointType.HipCenter
                               select j).FirstOrDefault();
            Joint Rightkneejoint = (from j in skeleton.Joints
                                    where j.JointType == JointType.KneeRight
                                    select j).FirstOrDefault();

            if (!(Headjoint.TrackingState == JointTrackingState.Tracked && Rightkneejoint.TrackingState == JointTrackingState.Tracked&&HipCenterjoint.TrackingState==JointTrackingState.Tracked))
                return false;

            double ag = GetAngle(Headjoint, HipCenterjoint, Rightkneejoint);

            if (ag < 90)
                SitUpFlag = true;
            
            if (ag > 120 && SitUpFlag)
            {
                SitUpFlag = false;
                return true;
            }
            return false;
        }

        private double GetAngle(Joint joint1, Joint joint2, Joint joint3)
        {
            Vector4 Body_vec1 = new Vector4();
            Vector4 Body_vec2 = new Vector4();
            Body_vec1.Z = 0;
            Body_vec2.Z = 0;
            Body_vec1.X = joint1.Position.X - joint2.Position.X;
            Body_vec1.Y = joint1.Position.Y - joint2.Position.Y;
            Body_vec1.Z = joint1.Position.Z - joint2.Position.Z;
            Body_vec2.X = joint3.Position.X - joint2.Position.X;
            Body_vec2.Y = joint3.Position.Y - joint2.Position.Y;
            Body_vec2.Z = joint3.Position.Z - joint2.Position.Z;

            double length1 = Math.Sqrt(Body_vec1.X * Body_vec1.X + Body_vec1.Y * Body_vec1.Y + Body_vec1.Z * Body_vec1.Z);
            double length2 = Math.Sqrt(Body_vec2.X * Body_vec2.X + Body_vec2.Y * Body_vec2.Y + Body_vec2.Z * Body_vec2.Z);
            double Dotproduct = Body_vec1.X * Body_vec2.X + Body_vec1.Y * Body_vec2.Y + Body_vec1.Z * Body_vec2.Z;
            double Angle = Math.Acos(Dotproduct / length1 / length2) / Math.PI * 180;
            return Angle;
        }
        //
    }
}
